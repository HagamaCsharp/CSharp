﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Create_Basic_ASP.NET_MVC_Application.Models
{
    public class Response
    {
        [Required(ErrorMessage = "Please enter your name")] //Validation for not entering a name in text box name
        [RegularExpression("^[a-zA-Z]+$", ErrorMessage = "Please enter a valid Name")] // validation for accepting only a-z and A-Z
        public string Name { get; set; }
        //=======================================================
        [Required(ErrorMessage = "Please enter your phone number")]//Validation for not entering a number in text box number
        [RegularExpression("^[0-9]{10}$", ErrorMessage ="Please enter a valid Number")]// validation for accepting only number and 10 digits
        public string MobileNumber { get; set; }
        //=======================================================
        [Required(ErrorMessage = "Please enter your email address")]//Validation for not entering a email in text box email
        [RegularExpression(".+\\@.+\\..+", ErrorMessage = "Please enter a valid email address")]// validation for accepting only Email Address
        public string Email { get; set; }
        //=======================================================
        [Required(ErrorMessage = "Please specify whether you'll attend or not")]//Validation for not selecting in Drowdown lsit box
        public bool? AttendOrNot { get; set; }

    }
}