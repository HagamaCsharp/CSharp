﻿using Create_Basic_ASP.NET_MVC_Application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Create_Basic_ASP.NET_MVC_Application.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            int hour = DateTime.Now.Hour;
            ViewBag.Greeting = hour < 12 ? "Good Morning" : "Good Afternoon";
            return View();
        }

        public ViewResult EnrollNow()
        {
            return View(); // go to the enrollnow view after triggered the submit of enroll now at the index
        }

        [HttpPost]
        public ViewResult EnrollNow(Response response)
        {
            if (response.Name == null || response.Email == null || response.MobileNumber == null || response.AttendOrNot == null && !ModelState.IsValid) //validation for not occupied any of the form
            {
                return View(response);
            }

            return View("Thanks", response); // go to the thanks view if all of the form are occupied and no error
        }
    }
}